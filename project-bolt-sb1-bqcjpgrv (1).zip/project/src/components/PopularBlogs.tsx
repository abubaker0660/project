import React from 'react';
import { Calendar, ArrowRight, Eye } from 'lucide-react';

const PopularBlogs = () => {
  const blogs = [
    {
      title: 'Top 10 Freelancing Platforms for Pakistani Developers',
      summary: 'Discover the best platforms to showcase your skills and find high-paying projects as a Pakistani freelancer.',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2024-01-18',
      readTime: '5 min read',
      views: '12.5K',
      category: 'Freelancing',
      author: 'Ahmad Hassan',
      authorImage: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=50'
    },
    {
      title: 'How to Build a Winning Portfolio as a Beginner',
      summary: 'Step-by-step guide to creating a professional portfolio that attracts clients and showcases your best work.',
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2024-01-15',
      readTime: '7 min read',
      views: '8.9K',
      category: 'Career Tips',
      author: 'Fatima Khan',
      authorImage: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=50'
    },
    {
      title: 'Digital Marketing Trends That Will Dominate 2024',
      summary: 'Stay ahead of the curve with the latest digital marketing strategies and trends for the upcoming year.',
      image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2024-01-12',
      readTime: '6 min read',
      views: '15.2K',
      category: 'Digital Marketing',
      author: 'Muhammad Ali',
      authorImage: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=50'
    },
    {
      title: 'The Complete Guide to Remote Work Success',
      summary: 'Master the art of remote work with proven strategies for productivity, communication, and work-life balance.',
      image: 'https://images.pexels.com/photos/4145032/pexels-photo-4145032.jpeg?auto=compress&cs=tinysrgb&w=400',
      date: '2024-01-10',
      readTime: '8 min read',
      views: '11.7K',
      category: 'Remote Work',
      author: 'Sara Ahmed',
      authorImage: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=50'
    }
  ];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <section className="py-20" style={{ backgroundColor: '#f5f5f5' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-16">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Popular Blogs
            </h2>
            <p className="text-xl text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Insights, tips, and strategies from industry experts
            </p>
          </div>
          <button className="hidden md:flex items-center px-6 py-3 text-white font-semibold rounded-lg hover:opacity-90 transition-colors" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            <span>View All</span>
            <ArrowRight size={20} className="ml-2" />
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {blogs.map((blog, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow group">
              <div className="relative overflow-hidden">
                <img
                  src={blog.image}
                  alt={blog.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4 text-white px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: '#f7941e' }}>
                  {blog.category}
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between text-sm text-gray-500 mb-3" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  <div className="flex items-center">
                    <Calendar size={14} className="mr-1" />
                    {formatDate(blog.date)}
                  </div>
                  <div className="flex items-center">
                    <Eye size={14} className="mr-1" />
                    {blog.views}
                  </div>
                </div>
                
                <h3 className="text-lg font-bold text-gray-900 mb-3 group-hover:text-orange-500 transition-colors line-clamp-2" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  {blog.title}
                </h3>
                
                <p className="text-gray-600 mb-4 leading-relaxed line-clamp-3" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  {blog.summary}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img
                      src={blog.authorImage}
                      alt={blog.author}
                      className="w-8 h-8 rounded-full object-cover mr-2"
                    />
                    <span className="text-sm text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>{blog.author}</span>
                  </div>
                  <span className="text-sm text-gray-500" style={{ fontFamily: 'Montserrat, sans-serif' }}>{blog.readTime}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12 md:hidden">
          <button className="inline-flex items-center px-6 py-3 text-white font-semibold rounded-lg hover:opacity-90 transition-colors" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            <span>View All Blogs</span>
            <ArrowRight size={20} className="ml-2" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default PopularBlogs;