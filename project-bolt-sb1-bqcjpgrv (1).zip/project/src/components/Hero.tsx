import React from 'react';
import { Play, ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen overflow-hidden" style={{ background: 'linear-gradient(135deg, #f7941e 0%, #ffb347 25%, #fff3d4 50%, #f5f5f5 100%)' }}>
      {/* Geometric Background Elements */}
      <div className="absolute inset-0">
        {/* Triangular shapes */}
        <div className="absolute top-20 left-10 w-32 h-32 opacity-20">
          <div className="w-full h-full bg-orange-400 transform rotate-45"></div>
        </div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-yellow-300 transform rotate-12 opacity-30"></div>
        <div className="absolute bottom-40 left-20 w-16 h-16 bg-orange-300 transform rotate-45 opacity-25"></div>
        <div className="absolute bottom-20 right-40 w-20 h-20 bg-yellow-400 rounded-full opacity-20"></div>
        
        {/* Dotted Pattern */}
        <div className="absolute left-0 top-1/4 opacity-30">
          <div className="grid grid-cols-8 gap-3">
            {Array.from({ length: 32 }).map((_, i) => (
              <div key={i} className="w-2 h-2 bg-orange-400 rounded-full"></div>
            ))}
          </div>
        </div>

        {/* Angular slices */}
        <div className="absolute top-0 right-0 w-1/3 h-full">
          <div className="w-full h-full bg-gradient-to-br from-orange-200 to-transparent opacity-20 transform skew-x-12"></div>
        </div>
        <div className="absolute bottom-0 left-0 w-1/4 h-1/2">
          <div className="w-full h-full bg-gradient-to-tr from-yellow-200 to-transparent opacity-15 transform -skew-x-12"></div>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center min-h-[80vh]">
          {/* Left Content */}
          <div className="mb-12 lg:mb-0 z-10">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Learn and Earn with{' '}
              <span style={{ color: '#f7941e' }}>DigiSkills.pk</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-600 mb-8 leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Master in-demand digital skills with Pakistan's leading online training platform. 
              Get certified, build your portfolio, and start earning from freelancing opportunities worldwide.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="flex items-center justify-center space-x-2 px-8 py-4 text-white rounded-lg hover:opacity-90 transition-all font-bold text-lg shadow-lg" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
                <span>Join Now Free Courses</span>
                <ArrowRight size={20} />
              </button>
              <button className="flex items-center justify-center space-x-2 px-8 py-4 border-2 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold text-lg" style={{ borderColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
                <Play size={20} />
                <span>Watch Demo</span>
              </button>
            </div>
          </div>

          {/* Right Image */}
          <div className="relative z-10">
            <div className="relative">
              {/* Slanted frame effect */}
              <div className="relative transform rotate-3 shadow-2xl">
                <div className="bg-gradient-to-br from-orange-400 to-yellow-400 rounded-2xl p-6">
                  <div className="bg-white rounded-xl p-4 transform -rotate-3">
                    <img
                      src="https://images.pexels.com/photos/3184454/pexels-photo-3184454.jpeg?auto=compress&cs=tinysrgb&w=600"
                      alt="DigiSkills Team"
                      className="w-full h-80 object-cover rounded-lg"
                    />
                  </div>
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -left-4 w-8 h-8 rounded-full animate-bounce" style={{ backgroundColor: '#f7941e' }}></div>
              <div className="absolute -bottom-4 -right-4 w-6 h-6 bg-yellow-500 rounded-full animate-bounce delay-300"></div>
              <div className="absolute top-1/2 -left-8 w-4 h-4 bg-orange-300 transform rotate-45 animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;