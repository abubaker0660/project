import React from 'react';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, Youtube, MessageCircle, GraduationCap } from 'lucide-react';

const Footer = () => {
  const quickLinks = [
    'About Us',
    'Courses',
    'Success Stories',
    'Career Opportunities',
    'Become an Instructor',
    'Terms & Conditions',
    'Privacy Policy',
    'Refund Policy'
  ];

  const courses = [
    'Web Development',
    'Mobile App Development',
    'Graphic Design',
    'Digital Marketing',
    'Data Science',
    'Video Editing',
    'UI/UX Design',
    'Cybersecurity'
  ];

  return (
    <footer className="text-white relative" style={{ background: 'linear-gradient(135deg, #333333 0%, #000000 100%)' }}>
      {/* Ask a Question Button */}
      <div className="fixed bottom-8 right-8 z-50">
        <button className="text-white p-4 rounded-full shadow-lg transition-colors hover:scale-110 transform" style={{ backgroundColor: '#f7941e' }}>
          <MessageCircle size={24} />
        </button>
        <div className="absolute bottom-16 right-0 bg-gray-800 text-white px-3 py-1 rounded-lg text-sm whitespace-nowrap" style={{ fontFamily: 'Montserrat, sans-serif' }}>
          Ask any question?
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <GraduationCap size={32} style={{ color: '#f7941e' }} />
              <h3 className="text-2xl font-bold" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                DigiSkills<span style={{ color: '#f7941e' }}>.pk</span>
              </h3>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Pakistan's leading digital skills training platform, empowering youth with industry-relevant skills for successful freelancing careers.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">
                <Twitter size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">
                <Instagram size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 transition-colors">
                <Youtube size={24} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>Quick Links</h4>
            <ul className="space-y-2">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h4 className="text-lg font-semibold mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>Popular Courses</h4>
            <ul className="space-y-2">
              {courses.map((course, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-orange-500 transition-colors" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                    {course}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-start">
                <MapPin size={20} style={{ color: '#f7941e' }} className="mr-3 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                    Office 101, IT Tower,<br />
                    Gulberg III, Lahore,<br />
                    Punjab, Pakistan
                  </p>
                </div>
              </div>
              <div className="flex items-center">
                <Phone size={20} style={{ color: '#f7941e' }} className="mr-3 flex-shrink-0" />
                <span className="text-gray-300" style={{ fontFamily: 'Montserrat, sans-serif' }}>+92 42 3571 2345</span>
              </div>
              <div className="flex items-center">
                <Mail size={20} style={{ color: '#f7941e' }} className="mr-3 flex-shrink-0" />
                <span className="text-gray-300" style={{ fontFamily: 'Montserrat, sans-serif' }}>info@digiskills.pk</span>
              </div>
            </div>

            <div className="mt-6">
              <h5 className="text-sm font-semibold mb-2 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>Support Hours</h5>
              <p className="text-gray-300 text-sm" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Monday - Friday: 9:00 AM - 6:00 PM<br />
                Saturday: 10:00 AM - 4:00 PM
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              © 2024 DigiSkills.pk. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-orange-500 text-sm transition-colors" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 text-sm transition-colors" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-500 text-sm transition-colors" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;