import React from 'react';
import { Calendar, ArrowRight } from 'lucide-react';

const NewsEvents = () => {
  const news = [
    {
      date: '2024-01-16',
      day: '16',
      month: 'Jun',
      year: '2025',
      title: 'New Partnership with Tech Giants for Job Placements',
      summary: 'DigiSkills.pk announces strategic partnerships with leading technology companies to enhance job placement opportunities for graduates.',
      image: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=300',
      category: 'Partnership'
    },
    {
      date: '2024-01-10',
      day: '10',
      month: 'Jun',
      year: '2025',
      title: 'Launch of Advanced AI and Machine Learning Course',
      summary: 'Introducing our most comprehensive AI/ML course designed for professionals looking to excel in artificial intelligence.',
      image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=300',
      category: 'New Course'
    },
    {
      date: '2024-01-05',
      day: '05',
      month: 'Jun',
      year: '2025',
      title: 'DigiSkills Graduates Secure $2M+ in Freelancing',
      summary: 'Our alumni have collectively earned over $2 million through freelancing platforms, showcasing the effectiveness of our training programs.',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=300',
      category: 'Success Story'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-16">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 hover:underline cursor-pointer transition-all uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              News & Events
            </h2>
          </div>
          <button className="hidden md:flex items-center px-6 py-3 text-white font-semibold rounded-lg hover:opacity-90 transition-colors" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            <span>View All</span>
            <ArrowRight size={20} className="ml-2" />
          </button>
        </div>

        {/* News Items */}
        <div className="space-y-12">
          {news.map((item, index) => (
            <article key={index} className="grid md:grid-cols-12 gap-6 items-start">
              {/* Left Column - Date and Image */}
              <div className="md:col-span-3 space-y-4">
                {/* Date Block */}
                <div className="text-center">
                  <div className="text-4xl font-bold mb-1" style={{ color: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
                    {item.day}
                  </div>
                  <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                    {item.month}, {item.year}
                  </div>
                </div>
                
                {/* Thumbnail Image */}
                <div className="w-full">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-32 object-cover rounded-lg shadow-md hover:shadow-lg transition-shadow"
                  />
                </div>
              </div>

              {/* Right Column - Content */}
              <div className="md:col-span-9">
                <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-3 hover:text-orange-500 transition-colors cursor-pointer" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  {item.title}
                </h3>
                
                <div className="flex items-center text-gray-500 text-sm mb-4" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  <Calendar size={16} className="mr-2" />
                  {new Date(item.date).toLocaleDateString('en-US', {
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </div>
                
                <p className="text-gray-600 mb-4 leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  {item.summary}
                </p>
                
                <button className="font-semibold hover:underline transition-all" style={{ color: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
                  Read More
                </button>
              </div>
            </article>
          ))}
        </div>

        {/* Mobile View All Button */}
        <div className="text-center mt-12 md:hidden">
          <button className="inline-flex items-center px-6 py-3 text-white font-semibold rounded-lg hover:opacity-90 transition-colors" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            <span>View All News</span>
            <ArrowRight size={20} className="ml-2" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default NewsEvents;