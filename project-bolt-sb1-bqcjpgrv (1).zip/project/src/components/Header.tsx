import React, { useState } from 'react';
import { Menu, X, Search, ArrowRight } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    'Home',
    'Courses',
    'News & Events',
    'How It Works',
    'Blog',
    'FAQs',
    'Contact Us'
  ];

  return (
    <header className="sticky top-0 z-50 bg-white" style={{ boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo Section */}
          <div className="flex items-center">
            <div className="flex items-center">
              {/* Logo Icon */}
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mr-3" style={{ background: 'linear-gradient(135deg, #f7941e 0%, #ffb347 100%)' }}>
                <div className="w-8 h-8 bg-white rounded-md flex items-center justify-center">
                  <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: '#f7941e' }}></div>
                </div>
              </div>
              
              {/* Logo Text */}
              <div className="flex flex-col">
                <h1 className="text-2xl font-bold leading-tight" style={{ fontFamily: 'Open Sans, sans-serif' }}>
                  <span className="text-gray-800">Digi</span>
                  <span style={{ color: '#f7941e' }}>Skills</span>
                  <span className="text-gray-800">.pk</span>
                </h1>
                <p className="text-xs text-gray-500 leading-none" style={{ fontFamily: 'Open Sans, sans-serif' }}>
                  Sara Jahan Hamara
                </p>
              </div>
            </div>
          </div>

          {/* Center Navigation Menu */}
          <nav className="hidden lg:flex items-center space-x-8">
            {menuItems.map((item, index) => (
              <a
                key={item}
                href="#"
                className={`text-base font-medium transition-colors hover:text-orange-500 ${
                  index === 0 
                    ? 'font-semibold' 
                    : 'text-gray-700'
                }`}
                style={{ 
                  fontFamily: 'Open Sans, sans-serif',
                  color: index === 0 ? '#f7941e' : '#333333'
                }}
              >
                {item}
              </a>
            ))}
          </nav>

          {/* Right Side - Search and Auth */}
          <div className="hidden lg:flex items-center space-x-6">
            {/* Search Icon */}
            <button className="p-2 text-gray-600 hover:text-orange-500 transition-colors">
              <Search size={20} />
            </button>
            
            {/* Sign In */}
            <a 
              href="#" 
              className="text-base font-medium transition-colors hover:underline"
              style={{ 
                color: '#f7941e',
                fontFamily: 'Open Sans, sans-serif'
              }}
            >
              Sign In
            </a>
            
            {/* Sign Up Button */}
            <button 
              className="inline-flex items-center px-6 py-3 text-base font-bold text-white transition-all hover:shadow-lg"
              style={{ 
                backgroundColor: '#f7941e',
                borderRadius: '25px',
                fontFamily: 'Open Sans, sans-serif'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#e67c12';
                e.currentTarget.style.transform = 'translateY(-1px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#f7941e';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              Sign Up
              <ArrowRight size={16} className="ml-2" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-700 hover:text-orange-500 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="lg:hidden bg-white border-t shadow-lg">
          <div className="px-4 pt-2 pb-3 space-y-1">
            {menuItems.map((item, index) => (
              <a
                key={item}
                href="#"
                className={`block px-3 py-3 text-base font-medium transition-colors ${
                  index === 0 
                    ? 'font-semibold' 
                    : 'text-gray-700 hover:text-orange-500 hover:bg-gray-50'
                }`}
                style={{ 
                  fontFamily: 'Open Sans, sans-serif',
                  color: index === 0 ? '#f7941e' : '#333333'
                }}
              >
                {item}
              </a>
            ))}
            
            <div className="px-3 py-4 space-y-3 border-t border-gray-200 mt-3">
              <div className="flex items-center justify-center mb-4">
                <button className="p-2 text-gray-600">
                  <Search size={20} />
                </button>
              </div>
              
              <a 
                href="#" 
                className="block text-center py-3 text-base font-medium"
                style={{ 
                  color: '#f7941e',
                  fontFamily: 'Open Sans, sans-serif'
                }}
              >
                Sign In
              </a>
              
              <button 
                className="w-full inline-flex items-center justify-center px-6 py-3 text-base font-bold text-white transition-colors"
                style={{ 
                  backgroundColor: '#f7941e',
                  borderRadius: '25px',
                  fontFamily: 'Open Sans, sans-serif'
                }}
              >
                Sign Up
                <ArrowRight size={16} className="ml-2" />
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;