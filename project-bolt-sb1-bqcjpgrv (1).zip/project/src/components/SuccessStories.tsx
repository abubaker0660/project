import React from 'react';
import { DollarSign, Star, Quote } from 'lucide-react';

const SuccessStories = () => {
  const topEarners = [
    {
      name: 'Ahmad Hassan',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150',
      earnings: '$45,000',
      skill: 'Web Development',
      rating: 4.9,
      testimonial: 'DigiSkills.pk transformed my career completely. From zero to earning $45K annually in just 8 months!'
    },
    {
      name: 'Fatima Khan',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
      earnings: '$38,500',
      skill: 'Graphic Design',
      rating: 4.8,
      testimonial: 'The practical approach and industry connections helped me build a successful freelancing business.'
    },
    {
      name: 'Muhammad Ali',
      image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150',
      earnings: '$52,000',
      skill: 'Digital Marketing',
      rating: 5.0,
      testimonial: 'Best investment I ever made. Now I run my own digital marketing agency with 15+ clients.'
    },
    {
      name: 'Sara Ahmed',
      image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=150',
      earnings: '$41,200',
      skill: 'Mobile App Development',
      rating: 4.9,
      testimonial: 'From housewife to successful app developer. DigiSkills.pk made it possible!'
    },
    {
      name: 'Hassan Malik',
      image: 'https://images.pexels.com/photos/2380794/pexels-photo-2380794.jpeg?auto=compress&cs=tinysrgb&w=150',
      earnings: '$48,800',
      skill: 'Data Science',
      rating: 4.8,
      testimonial: 'The comprehensive curriculum and mentorship helped me land my dream job at a tech startup.'
    }
  ];

  return (
    <section className="py-20 text-white" style={{ background: 'linear-gradient(135deg, #333333 0%, #000000 100%)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Success Stories
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Meet our top earning graduates who have built successful careers through DigiSkills.pk
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {topEarners.slice(0, 3).map((earner, index) => (
            <div key={index} className="bg-gray-800 rounded-xl p-6 hover:bg-gray-700 transition-colors">
              <div className="flex items-center mb-4">
                <img
                  src={earner.image}
                  alt={earner.name}
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h3 className="text-xl font-bold text-white" style={{ fontFamily: 'Montserrat, sans-serif' }}>{earner.name}</h3>
                  <p className="font-semibold" style={{ color: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>{earner.skill}</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <DollarSign size={20} className="text-green-500 mr-1" />
                  <span className="text-2xl font-bold text-green-500" style={{ fontFamily: 'Montserrat, sans-serif' }}>{earner.earnings}</span>
                  <span className="text-gray-400 ml-1" style={{ fontFamily: 'Montserrat, sans-serif' }}>/year</span>
                </div>
                <div className="flex items-center">
                  <Star size={16} className="text-yellow-500 mr-1" />
                  <span className="text-white" style={{ fontFamily: 'Montserrat, sans-serif' }}>{earner.rating}</span>
                </div>
              </div>
              
              <div className="relative">
                <Quote size={24} style={{ color: '#f7941e' }} className="mb-2" />
                <p className="text-gray-300 italic leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  "{earner.testimonial}"
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Top Earners */}
        <div className="grid md:grid-cols-2 gap-8">
          {topEarners.slice(3).map((earner, index) => (
            <div key={index} className="bg-gray-800 rounded-xl p-6 hover:bg-gray-700 transition-colors">
              <div className="flex items-center mb-4">
                <img
                  src={earner.image}
                  alt={earner.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white" style={{ fontFamily: 'Montserrat, sans-serif' }}>{earner.name}</h3>
                  <p className="font-semibold" style={{ color: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>{earner.skill}</p>
                </div>
                <div className="text-right">
                  <div className="flex items-center">
                    <DollarSign size={16} className="text-green-500 mr-1" />
                    <span className="text-xl font-bold text-green-500" style={{ fontFamily: 'Montserrat, sans-serif' }}>{earner.earnings}</span>
                  </div>
                  <div className="flex items-center">
                    <Star size={14} className="text-yellow-500 mr-1" />
                    <span className="text-white text-sm" style={{ fontFamily: 'Montserrat, sans-serif' }}>{earner.rating}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-300 text-sm italic" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                "{earner.testimonial}"
              </p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="inline-flex items-center px-8 py-3 text-white font-semibold rounded-lg hover:opacity-90 transition-colors" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            View All Success Stories
          </button>
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;