import React from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';

const CTABanner = () => {
  const benefits = [
    'Free course enrollment',
    'Industry-certified training',
    'Job placement assistance',
    'Lifetime community access'
  ];

  return (
    <section className="py-20 text-white relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #7c3aed 50%, #1e40af 100%)' }}>
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-32 h-32 bg-blue-400 rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-purple-400 rounded-full opacity-10 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-blue-300 rounded-full opacity-10 animate-pulse delay-500"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
          {/* Left Content */}
          <div className="mb-12 lg:mb-0">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Be Your Own Boss
            </h2>
            <p className="text-xl text-gray-200 mb-8 leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              Join thousands of successful graduates who have built thriving careers through our comprehensive digital skills training programs.
            </p>
            
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center">
                  <CheckCircle size={20} className="text-green-400 mr-3 flex-shrink-0" />
                  <span className="text-gray-200" style={{ fontFamily: 'Montserrat, sans-serif' }}>{benefit}</span>
                </div>
              ))}
            </div>
            
            <button className="inline-flex items-center px-8 py-4 text-white font-bold text-lg rounded-lg hover:opacity-90 transition-colors shadow-lg" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
              <span>Join Now It's Free</span>
              <ArrowRight size={24} className="ml-2" />
            </button>
          </div>

          {/* Right Illustration */}
          <div className="relative">
            <div className="bg-gradient-to-br from-orange-400 to-yellow-400 rounded-2xl p-8 transform rotate-3 shadow-2xl">
              <div className="bg-white rounded-xl p-6 transform -rotate-3">
                <img
                  src="https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Freelancer working"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </div>
            </div>
            
            {/* Floating Elements */}
            <div className="absolute -top-4 -left-4 w-8 h-8 rounded-full animate-bounce" style={{ backgroundColor: '#f7941e' }}></div>
            <div className="absolute -bottom-4 -right-4 w-6 h-6 bg-yellow-400 rounded-full animate-bounce delay-300"></div>
            <div className="absolute top-1/2 -right-8 w-4 h-4 bg-orange-300 transform rotate-45 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTABanner;