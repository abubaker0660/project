import React from 'react';
import { Monitor, Smartphone, PenTool, TrendingUp, Users, Clock } from 'lucide-react';

const Courses = () => {
  const courses = [
    {
      icon: Monitor,
      title: 'Web Development',
      description: 'Learn HTML, CSS, JavaScript, React, and Node.js to build modern web applications.',
      enrollments: '12,500',
      duration: '3 months',
      level: 'Beginner to Advanced',
      image: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Smartphone,
      title: 'Mobile App Development',
      description: 'Master React Native and Flutter to create cross-platform mobile applications.',
      enrollments: '8,200',
      duration: '4 months',
      level: 'Intermediate',
      image: 'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: PenTool,
      title: 'Graphic Design',
      description: 'Learn Adobe Photoshop, Illustrator, and Figma to create stunning visual designs.',
      enrollments: '15,800',
      duration: '2 months',
      level: 'Beginner',
      image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: TrendingUp,
      title: 'Digital Marketing',
      description: 'Master SEO, SEM, social media marketing, and content marketing strategies.',
      enrollments: '18,900',
      duration: '2.5 months',
      level: 'Beginner to Advanced',
      image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: Monitor,
      title: 'Data Science',
      description: 'Learn Python, machine learning, and data analysis to become a data scientist.',
      enrollments: '6,500',
      duration: '5 months',
      level: 'Advanced',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400'
    },
    {
      icon: PenTool,
      title: 'Video Editing',
      description: 'Master Adobe Premiere Pro and After Effects for professional video production.',
      enrollments: '9,300',
      duration: '2 months',
      level: 'Beginner to Intermediate',
      image: 'https://images.pexels.com/photos/3945321/pexels-photo-3945321.jpeg?auto=compress&cs=tinysrgb&w=400'
    }
  ];

  return (
    <section className="py-20" style={{ backgroundColor: '#f8f9fa' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Courses Offered
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Choose from our comprehensive range of industry-relevant courses designed to boost your digital career.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group">
              <div className="relative overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 right-4 text-white px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: '#f7941e' }}>
                  {course.level}
                </div>
              </div>
              
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mr-4">
                    <course.icon size={24} style={{ color: '#f7941e' }} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900" style={{ fontFamily: 'Montserrat, sans-serif' }}>{course.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-4 leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>{course.description}</p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  <div className="flex items-center">
                    <Users size={16} className="mr-1" />
                    {course.enrollments} enrolled
                  </div>
                  <div className="flex items-center">
                    <Clock size={16} className="mr-1" />
                    {course.duration}
                  </div>
                </div>
                
                <button className="w-full text-white py-3 rounded-lg font-semibold hover:opacity-90 transition-colors" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Courses;