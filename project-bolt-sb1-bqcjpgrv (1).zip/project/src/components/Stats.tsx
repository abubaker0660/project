import React, { useState, useEffect } from 'react';
import { Monitor, Clipboard, UserPlus, ArrowRight, BarChart3, PieChart, TrendingUp } from 'lucide-react';

const Stats = () => {
  const [animationComplete, setAnimationComplete] = useState(false);
  const [counters, setCounters] = useState([0, 0, 0]);

  const statsData = [
    {
      icon: Monitor,
      title: 'Overall Sign-ups',
      number: '3,782,663',
      animatedNumber: 3782663
    },
    {
      icon: Clipboard,
      title: 'Overall Enrollments',
      number: '4,716,047',
      animatedNumber: 4716047
    },
    {
      icon: UserPlus,
      title: 'DSTP3.0-Batch-01 Enrollments',
      number: '141,102',
      animatedNumber: 141102,
      label: 'Remaining Seats: 159,398'
    }
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      // Animate counters from 0 to 100
      let count = 0;
      const interval = setInterval(() => {
        count += 2;
        setCounters([count, count, count]);
        
        if (count >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setAnimationComplete(true);
          }, 500);
        }
      }, 40);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const formatNumber = (num: number) => {
    return num.toLocaleString();
  };

  return (
    <section className="py-20 text-white relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #7c3aed 50%, #1e40af 100%)' }}>
      {/* Background Illustrations */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10">
          <BarChart3 size={120} className="text-white" />
        </div>
        <div className="absolute top-20 right-20">
          <PieChart size={100} className="text-white" />
        </div>
        <div className="absolute bottom-20 left-1/4">
          <TrendingUp size={80} className="text-white" />
        </div>
        <div className="absolute bottom-10 right-10">
          <BarChart3 size={90} className="text-white" />
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Our Impact in Numbers
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Real-time statistics showing our growing community and success
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {statsData.map((stat, index) => (
            <div key={index} className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-opacity-20 transition-all duration-300 border border-white border-opacity-20">
              {stat.label && (
                <div className="mb-4">
                  <span className="inline-block px-4 py-2 rounded-full text-sm font-semibold text-white" style={{ backgroundColor: '#f7941e' }}>
                    {stat.label}
                  </span>
                </div>
              )}
              
              <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: '#f7941e' }}>
                <stat.icon size={32} className="text-white" />
              </div>
              
              <div className="mb-4">
                {!animationComplete ? (
                  <div className="text-6xl font-bold mb-2 transition-all duration-500" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                    {counters[index]}
                  </div>
                ) : (
                  <div className="text-4xl md:text-5xl font-bold mb-2 transition-all duration-500" style={{ fontFamily: 'Montserrat, sans-serif', color: '#f7941e' }}>
                    {formatNumber(stat.animatedNumber)}
                  </div>
                )}
              </div>
              
              <div className="text-xl font-semibold text-white" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                {stat.title}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button className="inline-flex items-center px-8 py-4 text-white font-bold text-lg rounded-lg hover:opacity-90 transition-colors shadow-lg" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            <span>View More Insight</span>
            <ArrowRight size={24} className="ml-2" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default Stats;