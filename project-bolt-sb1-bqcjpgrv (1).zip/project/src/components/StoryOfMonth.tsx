import React from 'react';
import { Play, Award, DollarSign, Calendar, Star, Users, Briefcase } from 'lucide-react';

const StoryOfMonth = () => {
  const storyData = {
    name: 'Ayesha Nadeem',
    title: 'From Teacher to Tech Entrepreneur',
    image: 'https://images.pexels.com/photos/3184160/pexels-photo-3184160.jpeg?auto=compress&cs=tinysrgb&w=400',
    videoThumbnail: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800',
    earnings: '$65,000',
    course: 'Full Stack Development',
    duration: '6 months',
    rating: '4.9',
    clients: '50+',
    projects: '120+',
    achievement: 'Founded her own web development agency',
    quote: 'DigiSkills.pk didn\'t just teach me coding; it taught me how to build a business. Today, I employ 8 developers and serve clients globally.',
    highlights: [
      'Completed Full Stack Development course in 4 months',
      'Landed first freelance project within 2 weeks',
      'Built portfolio of 50+ successful projects',
      'Founded "TechCrafters" - a successful web agency'
    ]
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center bg-orange-100 px-6 py-3 rounded-full mb-6">
            <Award size={24} style={{ color: '#f7941e' }} className="mr-3" />
            <span className="font-bold text-lg" style={{ color: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>Story of the Month</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6 uppercase" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            {storyData.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>
            Discover how {storyData.name} transformed her career from teaching to building a thriving tech business
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
          {/* Left Side - Video and Profile */}
          <div className="space-y-8">
            {/* Video Thumbnail */}
            <div className="relative group cursor-pointer">
              <div className="relative overflow-hidden rounded-2xl shadow-2xl">
                <img
                  src={storyData.videoThumbnail}
                  alt="Story Video"
                  className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center group-hover:bg-opacity-30 transition-all">
                  <div className="w-24 h-24 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg" style={{ backgroundColor: '#f7941e' }}>
                    <Play size={36} className="text-white ml-1" />
                  </div>
                </div>
              </div>
            </div>

            {/* Profile Card */}
            <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-2xl p-8 border border-orange-100">
              <div className="flex items-center space-x-6">
                <img
                  src={storyData.image}
                  alt={storyData.name}
                  className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-lg"
                />
                <div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Montserrat, sans-serif' }}>{storyData.name}</h3>
                  <p className="font-semibold text-lg mb-2" style={{ color: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>{storyData.course} Graduate</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Star size={16} className="text-yellow-500 mr-1" />
                      <span>{storyData.rating} Rating</span>
                    </div>
                    <div className="flex items-center">
                      <Users size={16} className="mr-1" />
                      <span>{storyData.clients} Clients</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Content */}
          <div className="space-y-8">
            {/* Success Metrics */}
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center p-6 bg-green-50 rounded-xl border border-green-100">
                <DollarSign size={32} className="text-green-500 mx-auto mb-3" />
                <div className="text-3xl font-bold text-green-600 mb-1" style={{ fontFamily: 'Montserrat, sans-serif' }}>{storyData.earnings}</div>
                <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>Annual Revenue</div>
              </div>
              <div className="text-center p-6 bg-blue-50 rounded-xl border border-blue-100">
                <Calendar size={32} className="text-blue-500 mx-auto mb-3" />
                <div className="text-3xl font-bold text-blue-600 mb-1" style={{ fontFamily: 'Montserrat, sans-serif' }}>{storyData.duration}</div>
                <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>Training Duration</div>
              </div>
              <div className="text-center p-6 bg-purple-50 rounded-xl border border-purple-100">
                <Briefcase size={32} className="text-purple-500 mx-auto mb-3" />
                <div className="text-3xl font-bold text-purple-600 mb-1" style={{ fontFamily: 'Montserrat, sans-serif' }}>{storyData.projects}</div>
                <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>Projects Completed</div>
              </div>
            </div>

            {/* Quote */}
            <div className="bg-gradient-to-r from-orange-500 to-yellow-500 rounded-2xl p-8 text-white">
              <div className="text-6xl font-bold opacity-20 mb-4">"</div>
              <p className="text-lg leading-relaxed mb-4 italic" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                {storyData.quote}
              </p>
              <p className="font-semibold" style={{ fontFamily: 'Montserrat, sans-serif' }}>- {storyData.name}</p>
            </div>

            {/* Key Achievements */}
            <div className="bg-gray-50 rounded-2xl p-8">
              <h4 className="text-xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Montserrat, sans-serif' }}>Key Achievements</h4>
              <ul className="space-y-4">
                {storyData.highlights.map((highlight, index) => (
                  <li key={index} className="flex items-start">
                    <div className="w-3 h-3 rounded-full mt-2 mr-4 flex-shrink-0" style={{ backgroundColor: '#f7941e' }}></div>
                    <span className="text-gray-700 leading-relaxed" style={{ fontFamily: 'Montserrat, sans-serif' }}>{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <div className="text-center">
          <button className="inline-flex items-center px-10 py-4 text-white font-bold text-lg rounded-full hover:opacity-90 transition-all shadow-lg transform hover:scale-105" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
            <Play size={24} className="mr-3" />
            <span>Watch Full Story</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default StoryOfMonth;