import React from 'react';
import { Lightbulb, HelpCircle, Users, MousePointer } from 'lucide-react';
import { ArrowRight } from 'lucide-react';

const About = () => {
  const cards = [
    {
      icon: Lightbulb,
      text: 'What',
      fullText: 'is Digital Rozgar?',
      bgColor: '#333333'
    },
    {
      icon: HelpCircle,
      text: 'Why',
      fullText: 'Digital Rozgar?',
      bgColor: '#333333'
    },
    {
      icon: Users,
      text: 'Who',
      fullText: 'Should Join?',
      bgColor: '#333333'
    },
    {
      icon: MousePointer,
      text: 'Join Now',
      fullText: '',
      bgColor: '#f7941e',
      isSpecial: true
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-start">
          {/* Left Column - Text Content */}
          <div className="mb-12 lg:mb-0">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8" style={{ fontFamily: 'Montserrat, sans-serif' }}>
              About Digital Rozgar
            </h2>
            
            <div className="text-lg leading-relaxed mb-8" style={{ fontFamily: 'Montserrat, sans-serif', color: '#333333' }}>
              <p>
                Digital Rozgar is the largest Training Program in Pakistan offering best{' '}
                <span className="font-bold" style={{ color: '#f7941e' }}>Free Online Courses</span>{' '}
                in freelancing Skills with E-Certificates issued by VU and Ignite. Over{' '}
                <span className="font-bold" style={{ color: '#f7941e' }}>4.5 Million + trainings</span>{' '}
                have been imparted{' '}
                <span className="font-bold" style={{ color: '#f7941e' }}>since 2018</span>{' '}
                to generate skilled workforce in Future of Work and to strengthen digital economy of Pakistan.
              </p>
              <br />
              <p>
                The{' '}
                <span className="font-bold" style={{ color: '#f7941e' }}>Women Empowerment</span>{' '}
                is a key element of this program, as they benefit to learn and earn sitting in the comfort of their homes.
              </p>
            </div>
            
            <button className="inline-flex items-center px-8 py-4 text-white font-bold text-lg rounded-full hover:opacity-90 transition-opacity shadow-lg" style={{ backgroundColor: '#f7941e', fontFamily: 'Montserrat, sans-serif' }}>
              <span>View More</span>
              <ArrowRight size={20} className="ml-2" />
            </button>
          </div>

          {/* Right Column - Cards Grid */}
          <div className="grid grid-cols-2 gap-6">
            {cards.map((card, index) => (
              <div
                key={index}
                className={`aspect-square rounded-xl shadow-lg p-6 flex flex-col items-center justify-center text-center hover:shadow-xl transition-shadow cursor-pointer ${
                  card.isSpecial ? 'hover:scale-105 transform transition-transform' : ''
                }`}
                style={{ backgroundColor: card.bgColor }}
              >
                <div className="mb-4">
                  <card.icon 
                    size={48} 
                    className={card.isSpecial ? 'text-gray-800' : 'text-white'} 
                  />
                </div>
                <div className="text-lg font-bold" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  {card.isSpecial ? (
                    <span className="text-gray-800 text-xl">{card.text}</span>
                  ) : (
                    <>
                      <span style={{ color: '#f7941e' }}>{card.text}</span>
                      <span className="text-white"> {card.fullText}</span>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;