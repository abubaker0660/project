import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Courses from './components/Courses';
import Stats from './components/Stats';
import NewsEvents from './components/NewsEvents';
import SuccessStories from './components/SuccessStories';
import StoryOfMonth from './components/StoryOfMonth';
import PopularBlogs from './components/PopularBlogs';
import CTABanner from './components/CTABanner';
import MobileApp from './components/MobileApp';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <About />
      <Courses />
      <Stats />
      <NewsEvents />
      <SuccessStories />
      <StoryOfMonth />
      <PopularBlogs />
      <CTABanner />
      <Footer />
    </div>
  );
}

export default App;